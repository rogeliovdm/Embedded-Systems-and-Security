#include <xmc_gpio.h>

/*Morse code Assignment 1*/

/*Declaration of macros*/

/* SysTick timer frequency in Hz  */
#define TICKS_PER_SECOND 1000

/*Macros for each morse signal time*/
#define TICKS_WAIT_100MS 100
#define TICKS_WAIT_300MS 300
#define TICKS_WAIT_700MS 700
#define TICKS_WAIT_5S    5000

/*Struct definitions*/

const XMC_GPIO_CONFIG_t LED_config = \
        {.mode=XMC_GPIO_MODE_OUTPUT_PUSH_PULL,\
        .output_level=XMC_GPIO_OUTPUT_LEVEL_LOW,\
        .output_strength=XMC_GPIO_OUTPUT_STRENGTH_STRONG_SHARP_EDGE};


/* Variable for keeping track of time */
static volatile uint32_t ticks = 0;

/* Function Name: SysTick_Handler
********************************************************************************
* Summary:
* This is the interrupt handler function for the SysTick timer interrupt.
* It counts the time elapsed in milliseconds since the timer started. 
*
* Parameters:
*  none
*
* Return:
*  none
*
*******************************************************************************/
void SysTick_Handler(void)
{
    ticks++;
}

/*******************************************************************************
* Function Name: sys_now
********************************************************************************
* Summary:
* Returns the current time in milliseconds.
*
* Parameters:
*  none
*
* Return:
*  the current time in milliseconds
*
*******************************************************************************/
__STATIC_INLINE uint32_t sys_now(void)
{
    return ticks;
}

/*Function for ticks delay since the start of the loop in ms*/
void wait(uint32_t ms)
{

    uint32_t start = sys_now();

    /* Wait till parameter "ms" are elapsed 
        since the start of the loop */
    while ((sys_now() - start) < ms);
        
}


/*Declaration of functions*/

void morse_i(void);
void morse_c(void);
void morse_a(void);
void morse_n(void);
void morse_m(void);
void morse_o(void);
void morse_r(void);
void morse_s(void);
void morse_e(void);
void morse_wordSpace(void);
void span_5s(void);

/*Definition of private functions (for main.c)*/

void span_5s(void)
{
  //Wait 5 S
    wait(TICKS_WAIT_5S);
}

void morse_wordSpace(void)
{
  //Wait 700 ms
    wait(TICKS_WAIT_700MS);
}

void morse_i (void)
{
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
  
}

void morse_c (void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS); 
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}

void morse_a (void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //2 letters space  
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS); 
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}

void morse_n (void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS); 
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}

void morse_m (void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);    
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}


void morse_o (void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_r (void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}
    

void morse_s (void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}
     
void morse_e (void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}

/*Main function*/
int main(void) 
{        
    /*2nd parameter = 1 refers to LED 1*/
    XMC_GPIO_Init(XMC_GPIO_PORT1, 1, &LED_config);

        /* System timer configuration */
    SysTick_Config(SystemCoreClock / TICKS_PER_SECOND);
    
    while(1)
    {
    morse_i();
    morse_wordSpace();
    morse_c();
    morse_a();
    morse_n();
    morse_wordSpace();
    morse_m();
    morse_o();
    morse_r();
    morse_s();
    morse_e();
    span_5s();
    }
  
}
