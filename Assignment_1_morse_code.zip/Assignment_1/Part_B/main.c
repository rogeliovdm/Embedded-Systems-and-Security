#include <xmc_gpio.h>
#include <stdio.h>

/*Morse code Assignment 1*/

/*Declaration of macros*/

/* SysTick timer frequency in Hz  */
#define TICKS_PER_SECOND 1000

/*Macros for each morse signal time*/
#define TICKS_WAIT_100MS 100
#define TICKS_WAIT_300MS 300
#define TICKS_WAIT_700MS 700
#define TICKS_WAIT_5S    5000

/* Maximum Digits for elapsed time between presses */
#define MAX_DIGITS 10

/*Struct definitions*/
/*LED1*/
const XMC_GPIO_CONFIG_t LED_config = \
        {.mode=XMC_GPIO_MODE_OUTPUT_PUSH_PULL,\
        .output_level=XMC_GPIO_OUTPUT_LEVEL_LOW,\
        .output_strength=XMC_GPIO_OUTPUT_STRENGTH_STRONG_SHARP_EDGE};

/*Button 1*/        
const XMC_GPIO_CONFIG_t in_config = \
       {.mode=XMC_GPIO_MODE_INPUT_TRISTATE,\
       .output_level=XMC_GPIO_OUTPUT_LEVEL_LOW,\
       .output_strength=XMC_GPIO_OUTPUT_STRENGTH_STRONG_SHARP_EDGE};


/* Variable for keeping track of time */
static volatile uint32_t ticks = 0;

/* Function Name: SysTick_Handler
********************************************************************************
* Summary:
* This is the interrupt handler function for the SysTick timer interrupt.
* It counts the time elapsed in milliseconds since the timer started. 
*
* Parameters:
*  none
*
* Return:
*  none
*
*******************************************************************************/
void SysTick_Handler(void)
{
    ticks++;
}

/*******************************************************************************
* Function Name: sys_now
********************************************************************************
* Summary:
* Returns the current time in milliseconds.
*
* Parameters:
*  none
*
* Return:
*  the current time in milliseconds
*
*******************************************************************************/
__STATIC_INLINE uint32_t sys_now(void)
{
    return ticks;
}

/*Function for ticks delay since the start of the loop in ms*/
void wait(uint32_t ms)
{

    uint32_t start = sys_now();

    /* Wait till parameter "ms" are elapsed 
        since the start of the loop */
    while ((sys_now() - start) < ms);
        
}


/*Declaration of local functions */

void morse_i(void);
void morse_c(void);
void morse_a(void);
void morse_n(void);
void morse_m(void);
void morse_o(void);
void morse_r(void);
void morse_s(void);
void morse_e(void);
void morse_wordSpace(void);
void span_5s(void);

void morse_1(void);
void morse_2(void);
void morse_3(void);
void morse_4(void);
void morse_5(void);
void morse_6(void);
void morse_7(void);
void morse_8(void);
void morse_9(void);
void morse_0(void);

void convertNum(uint32_t presses_time);


/*Definition of private functions (for main.c)*/

void span_5s(void)
{
  //Wait 5 S
    wait(TICKS_WAIT_5S);
}

void morse_wordSpace(void)
{
  //Wait 700 ms
    wait(TICKS_WAIT_700MS);
}

void morse_i(void)
{
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
  
}

void morse_c(void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS); 
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}

void morse_a(void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //2 letters space  
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS); 
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}

void morse_n(void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS); 
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS); 
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}

void morse_m(void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);    
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}


void morse_o(void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_r(void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}
    

void morse_s(void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}
     
void morse_e(void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
}

void morse_1(void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_2 (void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_3 (void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_4 (void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_5 (void)
{
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_6 (void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_7 (void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_8 (void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_9 (void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //.
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    
}

void morse_0 (void)
{
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    //2 letters space
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_100MS);
    //-
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);
    wait(TICKS_WAIT_300MS);
    XMC_GPIO_ToggleOutput(XMC_GPIO_PORT1, 1);

}

void convertNum(uint32_t presses_time)
{
    uint8_t arr[MAX_DIGITS];
    uint8_t i = 0;
    short j = 0;
    uint8_t r;
  
    while (presses_time != 0) 
    {
        r = presses_time % 10;
        arr[i] = r;
        i++;
        presses_time = presses_time / 10;
    }
  
    /*Reverse the string to send presses_time*/
    for (j = i - 1; j > -1; j--) 
    {
        switch(arr[j])
        {
            case 1:
                morse_1();
                wait(TICKS_WAIT_100MS);
                break;
                
            case 2:
                morse_2();
                wait(TICKS_WAIT_100MS);
                break;
            case 3:
                morse_3();
                wait(TICKS_WAIT_100MS);
                break;            
            case 4:
                morse_4();
                wait(TICKS_WAIT_100MS);
                break;
            case 5:
                morse_5();
                wait(TICKS_WAIT_100MS);
                break;
            case 6:
                morse_6();
                wait(TICKS_WAIT_100MS);
                break;            
            case 7:
                morse_7();
                wait(TICKS_WAIT_100MS);
                break;
            case 8:
                morse_8();
                wait(TICKS_WAIT_100MS);
                break;
            case 9:
                morse_9();
                wait(TICKS_WAIT_100MS);
                break;            
            case 0:
                morse_0();
                wait(TICKS_WAIT_100MS);
                break;
        }
        
    }
            
}



/*Main function*/
int main(void) 
{
    uint8_t button1_counter = 0;
    uint8_t boot_timestamp = 0;
    uint32_t start_timestamp = 0;
    uint32_t final_timestamp = 0;
    uint32_t time_between_presses = 0;
    
    boot_timestamp = sys_now();
    
    /*2nd parameter = 1 refers to LED 1*/
    XMC_GPIO_Init(XMC_GPIO_PORT1, 1, &LED_config);
    //Button 1
    XMC_GPIO_Init(XMC_GPIO_PORT1, 14, &in_config);
    //Button 2
    XMC_GPIO_Init(XMC_GPIO_PORT1, 15, &in_config);
    

    
    /* System timer configuration */
    SysTick_Config(SystemCoreClock / TICKS_PER_SECOND);
    
    while(1)
    {   
        /*Case 1: If Button 1 is pressed once, send string once */
        if(XMC_GPIO_GetInput(XMC_GPIO_PORT1, 14) == 0) 
        {
            morse_i();
            morse_wordSpace();
            morse_c();
            morse_a();
            morse_n();
            morse_wordSpace();
            morse_m();
            morse_o();
            morse_r();
            morse_s();
            morse_e();
            button1_counter++;
            
            if(button1_counter == 1)
            {
                start_timestamp = sys_now();
                time_between_presses = boot_timestamp = start_timestamp;
            }
            if(button1_counter > 1)
            {
                final_timestamp = sys_now();
                time_between_presses = final_timestamp - start_timestamp;
                start_timestamp = final_timestamp;
            }
        }
        
        /* Case 2: If Button 1 has not been pressed, send 0*/
        if((XMC_GPIO_GetInput(XMC_GPIO_PORT1, 15) == 0) && (button1_counter == 0))
        {
            morse_0();
        }
        
        /* Case 3: Button 2 pressed and Button 1 has been pressed only once, send time from boot to 1st press of button 1 */
        if((XMC_GPIO_GetInput(XMC_GPIO_PORT1, 15) == 0) && (button1_counter == 1))
        {
            convertNum(time_between_presses);
        }
        /* Case 4: Button 2 pressed and Button 1 has been pressed more than once, send time from 1st press of button 1 to 2nd latest press of button 1*/
        if((XMC_GPIO_GetInput(XMC_GPIO_PORT1, 15) == 0) && (button1_counter > 1))
        {
            convertNum(time_between_presses);
        }
                
    }
  
}
